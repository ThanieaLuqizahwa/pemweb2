@extends('admin.sepuluh.app')
@section('content')
    <h1>Hallo gais ini about</h1>
@endsection
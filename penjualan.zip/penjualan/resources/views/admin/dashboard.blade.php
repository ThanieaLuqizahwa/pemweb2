@extends('admin.layout.app')
{{-- orang tua atau parent --}}
@section('content')
{{-- nama dari halaman atau anak --}}
    Ini adalah halaman dashboard
@endsection
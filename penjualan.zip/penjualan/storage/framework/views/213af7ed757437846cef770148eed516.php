<!-- banner -->
<section class="">
   <div id="myCarousel" class="carousel slide banner" data-ride="carousel">
      <div class="carousel-inner">
         <div class="carousel-item active">
            <div class="container">
               <div class="carousel-caption  banner_po">
                  <div class="row">
                     <div class="col-md-5">
                        <div class="">
                           <figure><img src="<?php echo e(asset('sepuluh/images/logo.png')); ?>" alt="#"/></figure>
                        </div>
                     </div>
                     <div class="col-md-7">
                        <div class="yoga_box">
                           <h1>10</h1>
                           <h1> <strong>W</strong> E <strong>E</strong> K</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption banner_po">
                  <div class="row">
                     <div class="col-md-5">
                        <div class="">
                           <figure><img src="<?php echo e(asset('sepuluh/images/logo.png')); ?>" alt="#"/></figure>
                        </div>
                     </div>
                     <div class="col-md-7">
                        <div class="yoga_box">
                           <h1>10</h1>
                           <h1> <strong>W</strong> E <strong>E</strong> K</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="carousel-item">
            <div class="container">
               <div class="carousel-caption banner_po">
                  <div class="row">
                     <div class="col-md-5">
                        <div class="">
                           <figure><img src="<?php echo e(asset('sepuluh/images/logo.png')); ?>" alt="#"/></figure>
                        </div>
                     </div>
                     <div class="col-md-7">
                        <div class="yoga_box">
                           <h1>10</h1>
                           <h1> <strong>W</strong> E <strong>E</strong> K</h1>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <i class="fa fa-arrow-left" aria-hidden="true"></i>
      <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <i class="fa fa-arrow-right" aria-hidden="true"></i>
      <span class="sr-only">Next</span>
      </a>
   </div>
</section>
</header>
<!-- end banner --><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\penjualan\resources\views/admin/sepuluh/banner.blade.php ENDPATH**/ ?>
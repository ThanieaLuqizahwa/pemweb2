<!--  footer -->
<footer>
    <div class="footer">
       <div class="container">
          <div class="row">
             <div class="col-sm-12">
                <div class=" border_top1"></div>
             </div>
          </div>
          <div class="row">
             <div class="col-md-4">
                <h3>QUICK LINKS</h3>
                <ul class="link_menu">
                   <li><a href="#">Home</a></li>
                   <li><a href="about.html"> About</a></li>
                </ul>
             </div>
             <div class=" col-md-3">
                <h3>TOP</h3>
                <p class="many">
                   There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humou
                </p>
             </div>
             <div class="col-lg-3 offset-mdlg-2     col-md-4 offset-md-1">
                <h3>Contact </h3>
                <ul class="conta">
                   <li><i class="fa fa-map-marker" aria-hidden="true"></i> Location</li>
                   <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"> demo@gmail.com</a></li>
                   <li><i class="fa fa-mobile" aria-hidden="true"></i> Call : +01 1234567890</li>
                </ul>
                <ul class="social_icon">
                   <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                   <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                   <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                   <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                </ul>
             </div>
          </div>
       </div>
       <div class="copyright">
          <div class="container">
             <div class="row">
                <div class="col-md-10 offset-md-1">
                   <p>© 2019 All Rights Reserved. Design by <a href="https://html.design/"> Free Html Templates</a></p>
                </div>
             </div>
          </div>
       </div>
    </div>
 </footer>
 <!-- end footer -->
 <!-- Javascript files-->
 <script src="<?php echo e(asset('sepuluh/js/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('sepuluh/js/bootstrap.bundle.min.js')); ?>"></script>
 <script src="<?php echo e(asset('sepuluh/js/jquery-3.0.0.min.js')); ?>"></script>
 <!-- sidebar -->
 <script src="<?php echo e(asset('sepuluh/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
 <script src="<?php echo e(asset('sepuluh/js/custom.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\penjualan\resources\views/admin/sepuluh/footer.blade.php ENDPATH**/ ?>
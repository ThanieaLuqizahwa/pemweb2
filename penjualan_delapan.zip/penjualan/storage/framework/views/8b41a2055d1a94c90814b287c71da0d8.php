<?php
    $nama = "Budi";
    $nilai = 60;
?>



    <?php if($nilai >= 60): ?>
        <?php
            $ket = "lulus";
        ?>
    <?php else: ?>
        <?php
            $ket = "tidak lulus"
        ?>    
    <?php endif; ?>

    Siswa yang bernama <?php echo e($nama); ?>

    <br>Dengan nilai <?php echo e($nilai); ?>

    <br>Dinyatakan <?php echo e($ket); ?><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\penjualan\resources\views/nilai.blade.php ENDPATH**/ ?>
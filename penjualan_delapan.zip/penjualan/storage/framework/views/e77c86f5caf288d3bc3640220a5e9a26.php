<?php echo $__env->make('admin.layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="layoutSidenav_content">
<main>
    <div class="container-fluid px-4">
    
    <?php echo $__env->yieldContent('content'); ?>
    
</div>
</main>
</div>
</div>
<?php echo $__env->make('admin.layout.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\laravel\penjualan\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>